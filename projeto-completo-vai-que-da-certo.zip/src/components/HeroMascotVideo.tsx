import React, { useRef, useEffect, useState } from 'react';
import armadilloPoster from '../assets/images/armadillo_calling_1790169038271.jpg';
import armadilloAlt from '../assets/images/armadillo_transparent_clean_1790170398950.jpg';

interface HeroMascotVideoProps {
  onScrollToJobs: () => void;
}

export const HeroMascotVideo: React.FC<HeroMascotVideoProps> = ({ onScrollToJobs }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoLoaded, setVideoLoaded] = useState(false);
  const [videoFailed, setVideoFailed] = useState(false);

  useEffect(() => {
    const video = videoRef.current;
    if (video) {
      video.defaultMuted = true;
      video.muted = true;
      video.play()
        .then(() => setVideoLoaded(true))
        .catch(() => {
          // Autoplay fallback: tenta no primeiro toque/clique da tela
          const handleFirstInteraction = () => {
            if (video) {
              video.play().then(() => setVideoLoaded(true)).catch(() => setVideoFailed(true));
            }
            window.removeEventListener('click', handleFirstInteraction);
            window.removeEventListener('touchstart', handleFirstInteraction);
          };
          window.addEventListener('click', handleFirstInteraction, { once: true });
          window.addEventListener('touchstart', handleFirstInteraction, { once: true });
        });
    }
  }, []);

  return (
    <div 
      onClick={onScrollToJobs}
      className="flex items-center justify-center lg:justify-end cursor-pointer select-none group transition-transform active:scale-95"
      title="Clique para ver as vagas de hoje!"
    >
      <div className="relative shrink-0">
        {/* Efeito Glow Dourado e Roxo em volta */}
        <div className="absolute inset-0 bg-gradient-to-tr from-yellow-400/40 via-purple-600/30 to-amber-300/40 blur-2xl rounded-3xl pointer-events-none group-hover:scale-110 transition-transform duration-500" />

        {/* Card do Mascote Oficial - Altíssima Qualidade e Confiabilidade */}
        <div className="w-48 sm:w-56 md:w-64 aspect-square rounded-3xl overflow-hidden shadow-[0_12px_36px_rgba(0,0,0,0.4)] border-3 border-yellow-400 bg-gradient-to-b from-[#2b124c] to-[#120726] relative flex items-center justify-center group-hover:scale-105 transition-all duration-300">
          {!videoFailed ? (
            <video
              ref={videoRef}
              autoPlay
              loop
              muted
              playsInline
              controls={false}
              preload="auto"
              poster={armadilloPoster}
              onPlaying={() => setVideoLoaded(true)}
              onError={() => setVideoFailed(true)}
              className="w-full h-full object-cover block"
            >
              <source src="/tatu-animado.mp4" type="video/mp4" />
              <source src="/TATU.mp4" type="video/mp4" />
              <source src="/tatu.mp4" type="video/mp4" />
              {/* Fallback de Imagem se a tag video não carregar */}
              <img 
                src={armadilloPoster || armadilloAlt} 
                alt="Mascote Tatu do Vai Que Dá Certo" 
                className="w-full h-full object-cover block" 
              />
            </video>
          ) : (
            <img 
              src={armadilloPoster || armadilloAlt} 
              alt="Mascote Tatu do Vai Que Dá Certo" 
              className="w-full h-full object-cover block" 
            />
          )}

          {/* Badge flutuante interativa */}
          <div className="absolute bottom-2 inset-x-2 py-1.5 px-2.5 bg-slate-950/90 backdrop-blur-md border border-yellow-400/80 rounded-2xl text-center shadow-lg">
            <span className="text-[10px] sm:text-xs font-black text-yellow-300 uppercase tracking-wider flex items-center justify-center gap-1.5">
              <span>🐾 Mascote Oficial</span>
              <span className="text-white">•</span>
              <span className="text-white">Ver Vagas</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
